package com.boa.customerapi.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import com.boa.customerapi.facades.CustomerFacade;
import com.boa.customerapi.models.Customer;

@Service
public class CustomerPublisher {

	@Autowired
	private CustomerFacade customerFacade;
	
	public boolean publishCustomerData(Customer customer) {
         MessageChannel msgChannel=customerFacade.outChannel();
         

         return  msgChannel.send(MessageBuilder
                 .withPayload(customer)
                 .setHeader(MessageHeaders.CONTENT_TYPE,
                         MimeTypeUtils.APPLICATION_JSON)
                 .build());


	}
	
}
