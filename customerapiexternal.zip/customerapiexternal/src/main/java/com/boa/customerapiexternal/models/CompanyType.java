package com.boa.customerapiexternal.models;

public enum CompanyType {
GOV,NGO,PUBLIC,PRIVATE
}
