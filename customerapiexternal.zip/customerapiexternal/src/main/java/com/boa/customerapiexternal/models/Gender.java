package com.boa.customerapiexternal.models;

public enum Gender {
MALE,FEMALE,TRANSGENDER
}
