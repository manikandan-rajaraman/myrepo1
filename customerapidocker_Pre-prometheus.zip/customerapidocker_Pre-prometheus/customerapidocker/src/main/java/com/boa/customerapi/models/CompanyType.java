package com.boa.customerapi.models;

public enum CompanyType {
GOV,NGO,PUBLIC,PRIVATE
}
