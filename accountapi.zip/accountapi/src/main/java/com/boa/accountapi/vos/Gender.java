package com.boa.accountapi.vos;

public enum Gender {
MALE,FEMALE,TRANSGENDER
}
