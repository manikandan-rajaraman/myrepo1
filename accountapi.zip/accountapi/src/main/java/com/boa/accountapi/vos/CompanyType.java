package com.boa.accountapi.vos;

public enum CompanyType {
GOV,NGO,PUBLIC,PRIVATE
}
